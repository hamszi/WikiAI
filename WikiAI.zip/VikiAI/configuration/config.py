from dataclasses import dataclass
from environs import Env

@dataclass
class Config:
    bot_token: str
    openrouter_api_key: str
    wikipedia_urls: list[str]

def load_config() -> Config:
    env = Env()
    env.read_env()
    
    return Config(
        bot_token=env.str("BOT_TOKEN"),
        openrouter_api_key=env.str("OPENROUTER_API_KEY"),
        wikipedia_urls=[
            "https://ru.wikipedia.org",
            "https://en.wikipedia.org",
            "https://de.wikipedia.org"
        ]
    ) 