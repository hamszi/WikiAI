from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from .keyboards import get_search_keyboard
from .ai_service import search_wikipedia
from configuration.config import load_config

router = Router()
config = load_config()

class SearchState(StatesGroup):
    waiting_for_query = State()

@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "👋 Привет! Я бот для поиска информации в Wikipedia с помощью AI.\n"
        "🔍 Нажмите кнопку 'Поиск' чтобы начать поиск.",
        reply_markup=get_search_keyboard()
    )

@router.callback_query(F.data == "search")
async def process_search_button(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer(
        "📝 Введите ваш поисковый запрос:"
    )
    await state.set_state(SearchState.waiting_for_query)
    await callback.answer()

@router.message(SearchState.waiting_for_query)
async def process_search_query(message: Message, state: FSMContext):
    await message.answer("🔍 Ищу информацию...")
    
    try:
        result = await search_wikipedia(message.text, config)
        await message.answer(result)
    except Exception as e:
        await message.answer(f"❌ Произошла ошибка: {str(e)}")
    
    await state.clear()
    await message.answer(
        "🔍 Хотите выполнить еще один поиск?",
        reply_markup=get_search_keyboard()
    ) 