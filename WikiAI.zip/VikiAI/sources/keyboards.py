from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_search_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(
                text="🔍 Поиск",
                callback_data="search"
            )
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard) 