import aiohttp
import json
from configuration.config import Config

async def search_wikipedia(query: str, config: Config) -> str:
    async with aiohttp.ClientSession() as session:
        response = await session.post(
            url="https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {config.openrouter_api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/yourusername/wikipedia-ai-bot",
                "X-Title": "Wikipedia AI Bot",
            },
            json={
                "model": "mistralai/mistral-small-3.1-24b-instruct:free",
                "messages": [
                    {
                        "role": "user",
                        "content": f"имитируй поиск информации о '{query}' в Wikipedia. Используй следующие источники: {', '.join(config.wikipedia_urls)}. Предоставь краткое и информативное описание."
                    }
                ]
            }
        )
        
        if response.status != 200:
            raise Exception(f"API вернул ошибку: {response.status}")
            
        data = await response.json()
        return data['choices'][0]['message']['content']

